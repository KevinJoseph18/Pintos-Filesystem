#include "filesys/inode.h"
#include <list.h>
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "threads/malloc.h"
#include "threads/synch.h"

/* Identifies an inode. */
#define INODE_MAGIC 0x494e4f44
#define DIRECT_BITS 0x1ff
#define INDIRECT_BITS 0xfe00
#define DOUBLY_INDIRECT_BITS 0x7f0000
#define POINTERS_PER_BLOCK 128
#define SECTOR_SIZE_LENGTH 9
#define SECTOR_INDEX_LENGTH 7
#define MAX_FILE_SIZE 8000000

/* On-disk inode.
   Must be exactly BLOCK_SECTOR_SIZE bytes long. */
struct inode_disk
  {
    block_sector_t start;               /* First data sector. */
    off_t length;                       /* File size in bytes. */
    unsigned magic;                     /* Magic number. */
    block_sector_t direct;              /* Sector number of
      direct data block */
    block_sector_t indirect;            /* Sector number of 
      indirect index block */
    block_sector_t doubly_indirect;     /* Sector number of
      doubly indirect index block */
    block_sector_t parent;              /* Sector number of
      parent directory */
    int is_dir;                        /* 1 if inode is directory
      0 if file */
    uint32_t unused[120];               /* Not used. */
  };

/* Returns the number of sectors to allocate for an inode SIZE
   bytes long. */
static inline size_t
bytes_to_sectors (off_t size)
{
  if (size == 0) {
    return 0;
  } else if ((size & (INDIRECT_BITS | DOUBLY_INDIRECT_BITS)) == 0)
  {
    return 1;
  } else if ((size & DOUBLY_INDIRECT_BITS) == 0)
  {
    return 1 + DIV_ROUND_UP (size, BLOCK_SECTOR_SIZE);
  } else {
    return 1 + POINTERS_PER_BLOCK + DIV_ROUND_UP(size, BLOCK_SECTOR_SIZE);
  }
}

/* In-memory inode. */
struct inode 
  {
    struct list_elem elem;              /* Element in inode list. */
    block_sector_t sector;              /* Sector number of disk location. */
    int open_cnt;                       /* Number of openers. */
    bool removed;                       /* True if deleted, false otherwise. */
    int deny_write_cnt;                 /* 0: writes ok, >0: deny writes. */
    struct inode_disk data;             /* Inode content. */
    struct lock eof_lock;               /* Lock for writing/reading off eof */
    off_t write_length;
  };

/* Returns the block device sector that contains byte offset POS
   within INODE.
   Returns -1 if INODE does not contain data for a byte at offset
   POS. */
static block_sector_t
byte_to_sector (const struct inode *inode, off_t pos) 
{
  ASSERT (inode != NULL);
  ASSERT (inode->data.magic == INODE_MAGIC);
  if (inode->write_length <= pos) {
    return -1;
  }
  off_t direct = pos & DIRECT_BITS;
  off_t indirect = (pos & INDIRECT_BITS) >> SECTOR_SIZE_LENGTH;
  off_t doubly_indirect = (pos & DOUBLY_INDIRECT_BITS) >> (SECTOR_SIZE_LENGTH + SECTOR_INDEX_LENGTH);
  if (doubly_indirect != 0)
  {
    block_sector_t* buffer1 = malloc(BLOCK_SECTOR_SIZE);
    block_sector_t* buffer2 = malloc(BLOCK_SECTOR_SIZE);
    block_read(fs_device, inode->data.doubly_indirect, buffer1);
    block_read(fs_device, buffer1[doubly_indirect], buffer2);
    block_sector_t result = buffer2[indirect];
    free(buffer1);
    free(buffer2);
    return result;
  } else if (indirect != 0)
  {
    block_sector_t* buffer = malloc(BLOCK_SECTOR_SIZE);
    block_read(fs_device, inode->data.indirect, buffer);
    block_sector_t result = buffer[indirect];
    free(buffer);
    return result;
  } else 
  {
    return inode->data.direct;
  }
}

/* List of open inodes, so that opening a single inode twice
   returns the same `struct inode'. */
static struct list open_inodes;

/* Initializes the inode module. */
void
inode_init (void) 
{
  list_init (&open_inodes);
}

/* Initializes an inode with LENGTH bytes of data and
   writes the new inode to sector SECTOR on the file system
   device.
   Returns true if successful.
   Returns false if memory or disk allocation fails. */
bool
inode_create (block_sector_t sector, off_t length)
{
  struct inode_disk *disk_inode = NULL;
  bool success = true;

  ASSERT (length >= 0);

  /* If this assertion fails, the inode structure is not exactly
     one sector in size, and you should fix that. */
  ASSERT (sizeof *disk_inode == BLOCK_SECTOR_SIZE);

  disk_inode = calloc (1, sizeof *disk_inode);
  if (disk_inode == NULL) 
    return false;

  disk_inode->length = length;
  disk_inode->magic = INODE_MAGIC;
  disk_inode->parent = ROOT_DIR_SECTOR;

  size_t sectors = bytes_to_sectors (length);
  size_t remaining = sectors;

  /* check for direct block */
  if (remaining && success)
  {
    disk_inode->direct = free_map_allocate_block();
    success = (disk_inode->direct >= 0);
    remaining--;
  }

  /* check for indirect blocks */
  if (remaining && success)
  {
    block_sector_t indirect_index_block = free_map_allocate_block();
    success = (indirect_index_block >= 0);
    remaining--;
    int i = 1;
    block_sector_t indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];
    /* iterate over entries of indirect index block */
    while (i < 128 && remaining && success)
    {
      indirect_block_buffer[i] = free_map_allocate_block();
      success = (indirect_block_buffer[i] >= 0);
      remaining--;
      i++; 
    }
    block_write(fs_device, indirect_index_block, indirect_block_buffer);
    disk_inode->indirect = indirect_index_block;
  }

  /* check for doubly-indirect blocks */
  if (remaining && success)
  {
    block_sector_t doubly_indirect_index_block = free_map_allocate_block();
    success = (doubly_indirect_index_block >= 0);
    remaining--;
    int i = 1;
    block_sector_t doubly_indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];

    /* iterate over entries of doubly-indirect index block */
    while (i < 128 && remaining && success)
    {
      block_sector_t indirect_index_block = free_map_allocate_block();
      success = (indirect_index_block >= 0);
      remaining--;
      int j = 0;
      block_sector_t indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];
      
      /* iterate over entries of indirect index block children of doubly-indirect index block */
      while (j < 128 && remaining && success)
      {
        indirect_block_buffer[j] = free_map_allocate_block();
        success = (indirect_block_buffer[j] >= 0);
        remaining--;
        j++;
      }
      doubly_indirect_block_buffer[i] = indirect_index_block;
      block_write(fs_device, indirect_index_block, indirect_block_buffer);
      i++;
    }
    block_write(fs_device, doubly_indirect_index_block, doubly_indirect_block_buffer);
    disk_inode->doubly_indirect = doubly_indirect_index_block;
  }
  block_write(fs_device, sector, disk_inode);
  free (disk_inode);
  return success;
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode *
inode_open (block_sector_t sector)
{
  struct list_elem *e;
  struct inode *inode;

  /* Check whether this inode is already open. */
  for (e = list_begin (&open_inodes); e != list_end (&open_inodes);
       e = list_next (e)) 
    {
      inode = list_entry (e, struct inode, elem);
      if (inode->sector == sector) 
        {
          inode_reopen (inode);
          return inode; 
        }
    }

  /* Allocate memory. */
  inode = malloc (sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front (&open_inodes, &inode->elem);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;
  lock_init(&inode->eof_lock);
  block_read (fs_device, inode->sector, &inode->data);
  inode->write_length = inode->data.length;
  return inode;
}

/* Reopens and returns INODE. */
struct inode *
inode_reopen (struct inode *inode)
{
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
block_sector_t
inode_get_inumber (const struct inode *inode)
{
  return inode->sector;
}


void
inode_set_parent (block_sector_t file_sector, struct inode *parent_dir)
{
  struct inode* file = inode_open(file_sector);
  file->data.parent = parent_dir->sector;
  inode_close(file);
}

struct inode *
inode_get_parent (struct inode *inode)
{
  return inode_open(inode->data.parent);
}
void
inode_set_dir(block_sector_t sector)
{
  struct inode *file = inode_open(sector);
  file->data.is_dir = 1;
  inode_close(file);
}


bool
inode_is_dir (struct inode *inode)
{
  return inode->data.is_dir;
}

int
inode_get_users(struct inode *inode)
{
  return inode->open_cnt;
}

/* Closes INODE and writes it to disk. (Does it?  Check code.)
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void
inode_close (struct inode *inode) 
{
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  if (inode->data.magic != INODE_MAGIC)
  {
    return;
  }

  block_write(fs_device, inode->sector, &inode->data);
  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0)
    {
      /* Remove from inode list and release lock. */
      list_remove (&inode->elem);
 
      /* Deallocate blocks if removed. */
      if (inode->removed) 
        {
          free_map_release (inode->sector, 1);
          free_map_release (inode->data.start,
                            bytes_to_sectors (inode->data.length)); 
        }

      free (inode); 
    }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void
inode_remove (struct inode *inode) 
{
  ASSERT (inode != NULL);
  inode->removed = true;
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t
inode_read_at (struct inode *inode, void *buffer_, off_t size, off_t offset) 
{
  uint8_t *buffer = buffer_;
  off_t bytes_read = 0;
  uint8_t *bounce = NULL;

  while (size > 0) 
    {
      /* Disk sector to read, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually copy out of this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Read full sector directly into caller's buffer. */
          block_read (fs_device, sector_idx, buffer + bytes_read);
        }
      else 
        {
          /* Read sector into bounce buffer, then partially copy
             into caller's buffer. */
          if (bounce == NULL) 
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }
          block_read (fs_device, sector_idx, bounce);
          memcpy (buffer + bytes_read, bounce + sector_ofs, chunk_size);
        }
      
      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_read += chunk_size;
    }
  free (bounce);

  return bytes_read;
}

bool 
inode_grow (struct inode *inode, int num_sectors, int old_sectors)
{
  struct inode_disk* disk_inode = &inode->data; 
  int remaining = num_sectors;
  int counter = 0;
  bool success = true;
  if (remaining && success)
  {
    
    if (counter >= old_sectors)
    {
      disk_inode->direct = free_map_allocate_block();
      success = (disk_inode->direct >= 0);
      
    }
    remaining--;
    counter++;
  }

  /* check for indirect blocks */
  if (remaining && success)
  {
    block_sector_t indirect_index_block;
    if (counter >= old_sectors)
    {
      indirect_index_block = free_map_allocate_block();
      success = (indirect_index_block >= 0);
    }
    else
    {
      indirect_index_block = disk_inode->indirect;
    }
    remaining--;
    counter++;
    int i = 1;

    block_sector_t indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];
    /* read in existing indirect index block if it exists */
    if (counter < old_sectors)
    {
      block_read(fs_device, indirect_index_block, indirect_block_buffer);
    }
      
    /* iterate over entries of indirect index block */
    while (i < 128 && remaining && success)
    {
      if (counter >= old_sectors)
      {
        indirect_block_buffer[i] = free_map_allocate_block();
        success = (indirect_block_buffer[i] >= 0);
      }
      remaining--;
      counter++;
      i++;
    }
    block_write(fs_device, indirect_index_block, indirect_block_buffer);
    disk_inode->indirect = indirect_index_block;
  }

  /* check for doubly-indirect blocks */
  if (remaining && success)
  {
    block_sector_t doubly_indirect_index_block;
    if (counter >= old_sectors)
    {
      doubly_indirect_index_block = free_map_allocate_block();
      success = (doubly_indirect_index_block >= 0);
    }
    else
    {
      doubly_indirect_index_block = disk_inode->doubly_indirect;
    }
    remaining--;
    counter++;
    int i = 1;
    block_sector_t doubly_indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];
    /*reads doubly indirect index block from disk */
    if (counter < old_sectors)
      block_read(fs_device, doubly_indirect_index_block, doubly_indirect_block_buffer);
    /* iterate over entries of doubly-indirect index block */
    while (i < 128 && remaining && success)
    {
      block_sector_t indirect_index_block;
      if (counter >= old_sectors)
      {
        indirect_index_block = free_map_allocate_block();
        success = (indirect_index_block >= 0);
      }
      else
        indirect_index_block = doubly_indirect_block_buffer[i];
      remaining--;
      counter++;
      int j = 0;

      block_sector_t indirect_block_buffer[BLOCK_SECTOR_SIZE / sizeof(block_sector_t)];
      if (counter < old_sectors)
        block_read(fs_device, indirect_index_block, indirect_block_buffer);
      /* iterate over entries of indirect index block children of doubly-indirect index block */
      while (j < 128 && remaining && success)
      {
        if (counter >= old_sectors)
        {
          indirect_block_buffer[j] = free_map_allocate_block();
          success = (indirect_block_buffer[j] >= 0);
        }
        remaining--;
        counter++;
        j++;
      }
      /* writes to double indirect index block */
      doubly_indirect_block_buffer[i] = indirect_index_block;
      /* writes each indirect index block to disk */
      block_write(fs_device, indirect_index_block, indirect_block_buffer);
      i++;
    }
    /*writes doubly indirect index block to disk */
    block_write(fs_device, doubly_indirect_index_block, doubly_indirect_block_buffer);
    disk_inode->doubly_indirect = doubly_indirect_index_block;
  }
  block_write(fs_device, inode->sector, disk_inode);
  return success;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode, but
   growth is not yet implemented.) */
off_t
inode_write_at (struct inode *inode, const void *buffer_, off_t size,
                off_t offset) 
{
  const uint8_t *buffer = buffer_;
  off_t bytes_written = 0;
  uint8_t *bounce = NULL;

  inode->write_length = inode->data.length;

  if (inode->deny_write_cnt)
    return 0;

  if (offset + size > inode->data.length)
  {
    if (!lock_held_by_current_thread(&inode->eof_lock))
    {
      lock_acquire(&inode->eof_lock);
    }
    if (offset + size >= MAX_FILE_SIZE)
    {
      /* TODO HANDLE LARGE FILE ERROR*/
    }
    
    int num_sectors = bytes_to_sectors(size + offset);
    int old_sectors = bytes_to_sectors(inode->data.length);
    if (!inode_grow(inode, num_sectors, old_sectors))
    {
      /* TODO handle no growth error */
    }
    inode->write_length = size + offset;
  }

  while (size > 0) 
    {
      /* Sector to write, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode->write_length - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually write into this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Write full sector directly to disk. */
          block_write (fs_device, sector_idx, buffer + bytes_written);
        }
      else 
        {
          /* We need a bounce buffer. */
          if (bounce == NULL) 
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }

          /* If the sector contains data before or after the chunk
             we're writing, then we need to read in the sector
             first.  Otherwise we start with a sector of all zeros. */
          if (sector_ofs > 0 || chunk_size < sector_left) 
            block_read (fs_device, sector_idx, bounce);
          else
            memset (bounce, 0, BLOCK_SECTOR_SIZE);
          memcpy (bounce + sector_ofs, buffer + bytes_written, chunk_size);
          block_write (fs_device, sector_idx, bounce);
        }

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_written += chunk_size;
    }
  free (bounce);
  if (inode->data.length != inode->write_length)
  {
    inode->data.length = inode->write_length;
  }
  if (lock_held_by_current_thread(&inode->eof_lock))
  {
    lock_release(&inode->eof_lock);
  }
  return bytes_written;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void
inode_deny_write (struct inode *inode) 
{
  inode->deny_write_cnt++;
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void
inode_allow_write (struct inode *inode) 
{
  ASSERT (inode->deny_write_cnt > 0);
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t
inode_length (const struct inode *inode)
{
  return inode->data.length;
}
