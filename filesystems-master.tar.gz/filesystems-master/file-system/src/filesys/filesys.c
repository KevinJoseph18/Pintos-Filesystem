#include "filesys/filesys.h"
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include "filesys/file.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "threads/thread.h"

/* Partition that contains the file system. */
struct block *fs_device;

static void do_format (void);

/* Initializes the file system module.
   If FORMAT is true, reformats the file system. */
void
filesys_init (bool format) 
{
  fs_device = block_get_role (BLOCK_FILESYS);
  if (fs_device == NULL)
    PANIC ("No file system device found, can't initialize file system.");

  inode_init ();
  free_map_init ();

  if (format) 
    do_format ();

  free_map_open ();
}

/* Shuts down the file system module, writing any unwritten data
   to disk. */
void
filesys_done (void) 
{
  free_map_close ();
}


int
get_parent_path_size(const char *name, char *filename)
{
  int num = strlen(filename);
  if ((strlen(name) == num + 1 && name[0] == '/') || strlen(name) == num)
    return 0;
  else
  {
    return strlen(name) - (num + 1);
  }
}

/* Creates a file named NAME with the given INITIAL_SIZE.
   Returns true if successful, false otherwise.
   Fails if a file named NAME already exists,
   or if internal memory allocation fails. */
bool
filesys_create (const char *name, off_t initial_size, bool isdir) 
{
  block_sector_t inode_sector = 0;

  char *filename = file_parse_path_filename(name);
  int size = get_parent_path_size(name, filename);
  char newname[size +  1];
  strlcpy(newname, name, size + 1);
  newname[size] = '\0';

  struct dir *dir = file_parse_path_dir(newname, NULL); 

  
  bool success = true;
  success = success && (dir != NULL);
  success = success && (free_map_allocate(1, &inode_sector));
  if (isdir)
    success = success && (dir_create(inode_sector, 8));
  else
    success = success && (inode_create(inode_sector, initial_size));
  success = success && dir_add(dir, filename, inode_sector);
  
  
  if (!success && inode_sector != 0) 
    free_map_release (inode_sector, 1);
  dir_close (dir);

  return success;
}


/* Opens the file with the given NAME.
   Returns the new file if successful or a null pointer
   otherwise.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
struct file *
filesys_open (const char *name)
{
  char *filename = file_parse_path_filename(name);
  int dirflag = 0;
  struct dir *dir = file_parse_path_dir(name, &dirflag);
  struct inode *inode = NULL;
  
  if (dir != NULL && dirflag)
  {
    struct file* res = file_open (dir_get_inode(dir));
    file_set_dir(res, dir);
    return res;
  }

  if (dir != NULL)
    dir_lookup (dir, filename, &inode);
  dir_close (dir);

  return file_open (inode);
}


/* Deletes the file named NAME.
   Returns true if successful, false on failure.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
bool
filesys_remove (const char *name) 
{
  char *filename = file_parse_path_filename(name);
  int size = get_parent_path_size(name, filename);
  char newname[size +  1];
  strlcpy(newname, name, size + 1);
  newname[size] = '\0';

  int dirflag;
  struct dir *dir = file_parse_path_dir(newname, &dirflag);
  ASSERT(dirflag); 

  bool success = dir != NULL && dir_remove (dir, filename);

  dir_close (dir); 

  
  
 
  return success;
}

bool 
filesys_chdir(const char *name)
{
  struct dir *dir = file_parse_path_dir(name, NULL);
  if (dir == NULL)
    return false;
  
  dir_close(thread_current()->wd);
  thread_current()->wd = dir;
  return true;
}

bool
filesys_mkdir(const char *name)
{
  char *filename = file_parse_path_filename(name);
  int num = strlen(filename);
  struct dir *dir;
  if (strlen(name) == 0)
    return false;
  
  char newname[strlen(name)];
  if (strlen(name) == num)
  {
    /* one word relative path*/
    dir = thread_current()->wd;
  }
  else if(strlen(name) == num + 1 && name[0] == '/')
  {
    dir = dir_open_root;
  }
  else
  {
    int char_needed = strlen(name) - (num + 1);
    strlcpy(newname, name, char_needed);
    dir = file_parse_path_dir(newname, NULL);
    if (dir == NULL)
      return false;
  }

  if (file_parse_path_dir(name, NULL) != NULL)
  {
    /* MKDIR is not needed because directory is already there */
    return false;
  }

  /* create folder named filename in directory dir */
  return filesys_create(name, 0, true);
}


char *
file_parse_path_filename(char *name)
{
  char* saveptr;
  char *token;
  char path[strlen(name) + 1];
  strlcpy(path, name, strlen(name) + 1);
  int counter = 0;
  for (token = strtok_r(path, "/", &saveptr); token != NULL; token = strtok_r(NULL, " ", &saveptr))
  {
    counter = strlen(token);
  }
  return name + (strlen(name) - counter);
}
struct dir*
file_parse_path_dir(char *name, int *dirflag)
{
  if (dirflag)
  {
    *dirflag = 1;
  }
  
  if (name[0] == '\0' || ((strlen(name) == 1) && name[0] == '/'))
  {
    if (dirflag)
      *dirflag = 1;
    return dir_open_root();
  }
  char *saveptr;
  char *token;
  char path[strlen(name) + 1];
  strlcpy(path, name, strlen(name) + 1);

  struct dir *dir;
  /* absolute vs relative paths */
  if (path[0] == '/' || thread_current()->wd == NULL)
    dir = dir_open_root();
  else
    dir = thread_current()->wd;
  
  
  struct inode *inode;
  for (token = strtok_r(path, "/", &saveptr); token != NULL; token = strtok_r(NULL, " ", &saveptr))
  {
    /* token is . */
    if (strcmp(token, ".") == 0)
    {
      continue;
    }
    /* token is .. */
   
    if (strcmp(token, "..") == 0)
    {
      inode = dir_get_parent(dir);
      if (inode == NULL)
      {
        if (dirflag)
        {
          *dirflag = 0;
        } 
        /* TODO */
        return NULL;
      }
    }

    /* token is a file name */
    else
    {
      /* check if file is in the directory */
      if (!dir_lookup(dir, token, &inode))
      {
        if (dirflag)
        {
          *dirflag = 0;
        } 
        return NULL;
      }
    }

    if (inode_is_dir(inode))
    {
      if (dirflag != NULL)
        *dirflag = 1;
      if (dir != thread_current()->wd)
      {
        dir_close(dir);
      }
      dir = dir_open(inode);
    }
    else
    {
      if (dirflag != NULL)
        *dirflag = 0;
      inode_close(inode);
    }
  }
  return dir;
}

/* Formats the file system. */
static void
do_format (void)
{
  printf ("Formatting file system...");
  free_map_create ();
  if (!dir_create (ROOT_DIR_SECTOR, 16))
    PANIC ("root directory creation failed");
  free_map_close ();
  printf ("done.\n");
}
