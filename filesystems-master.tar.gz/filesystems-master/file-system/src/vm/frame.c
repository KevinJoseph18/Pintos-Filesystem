#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "threads/vaddr.h"
#include "threads/loader.h"

#define OFFSET_BITS 12
#define FRAME_NUM_BITS 20

uint32_t user_frame_offset;
size_t num_frames;

size_t frame_num_from_kernel_addr(void* kernel_addr) 
{
    uintptr_t phys_addr = vtop(kernel_addr);
    return (((unsigned) phys_addr) >> OFFSET_BITS) - user_frame_offset;
}

bool frame_table_init(uint32_t user_pages) 
{
    user_frame_offset = init_ram_pages - user_pages + 1;
    frame_table = malloc(user_pages * sizeof(struct frame_table_entry));
    /* pre-emptively allocate all frame-entries */
    int i;
    for (i = 0; i < user_pages; i++) 
    {
        void* kernel_addr = palloc_get_page(PAL_USER);
        if (kernel_addr == NULL) 
        {
            /* we have less user pages available than we're supposed to; 
            that's ok, update number of frames to be correct.*/
            num_frames = i;
            break;
        }
        /* get frame number from kernel_addr */
        size_t frame_num = frame_num_from_kernel_addr(kernel_addr);
        struct frame_table_entry* entry = (frame_table + frame_num);
       
        entry->is_free = true;
        lock_init(&entry->mutex);
        entry->kernel_addr = kernel_addr;
        entry->owner = NULL;
        entry->sup_page_entry = NULL;
    }
}

void* allocate_frame(struct thread* owner, bool zero)
{
    /* iterate over frame table until we hit a free frame */
    void* return_address = NULL;
    int i;
    for (i = 0; i < num_frames; i++) {
        struct frame_table_entry* entry = (frame_table + i);
        lock_acquire(&entry->mutex);
        if (entry->is_free)
        {
            /* found it */
            entry->is_free = false;
            entry->owner = owner;
            entry->sup_page_entry = NULL; /* TODO: SUPPLEMENTAL PAGE TABLE */
            return_address = entry->kernel_addr;
        }
        lock_release(&entry->mutex);
        if (return_address != NULL)
        {
            
            break;
        }
    }
    if (return_address == NULL)
    {
        /*no pages available */
        PANIC("\n OUT OF PAGES \n");
    }
    
    if (return_address != NULL && zero) 
    {
        memset (return_address, 0, PGSIZE);
    }
    return return_address;
}

void free_frame(void* kernel_addr) 
{
    size_t frame_num = frame_num_from_kernel_addr(kernel_addr);
    struct frame_table_entry* entry = (frame_table + frame_num);
    lock_acquire(&entry->mutex);
    if (entry->is_free) 
    {
        /* freeing already free frame. Not sure if should punish caller
        or not. */
        lock_release(&entry->mutex);
        return;
    }
    entry->is_free = true;
    entry->owner = NULL;
    entry->sup_page_entry = NULL;
    lock_release(&entry->mutex);
}


