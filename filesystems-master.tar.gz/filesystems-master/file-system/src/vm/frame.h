#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"

struct frame_table_entry 
{
    struct lock mutex;
    bool is_free;
    void* kernel_addr;
    struct thread* owner;
    struct sup_page_entry* sup_page_entry;
    // Maybe store information for memory mapped files here too?
};

size_t frame_num_from_kernel_addr(void* kernel_addr);

bool frame_table_init(uint32_t frames);

struct frame_table_entry* frame_table;

#endif /* VM_FRAME_H */
